print "IMPORTING minimal_ext"
import minimal_ext
print "DONE IMPORTING minimal_ext"

