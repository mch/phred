// Copyright David Abrahams 2001. Permission to copy, use,
// modify, sell and distribute this software is granted provided this
// copyright notice appears in all copies. This software is provided
// "as is" without express or implied warranty, and with no claim as
// to its suitability for any purpose.
#ifndef SIMPLE_TYPE_DWA2001128_HPP
# define SIMPLE_TYPE_DWA2001128_HPP

struct simple
{
    char* s;
};

#endif // SIMPLE_TYPE_DWA2001128_HPP
