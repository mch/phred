#!/usr/bin/env python

from Pyste import pyste
pyste.main()
