#include "nested.h"

int nested::X::staticXValue = 10;
int nested::X::Y::staticYValue = 20; 
