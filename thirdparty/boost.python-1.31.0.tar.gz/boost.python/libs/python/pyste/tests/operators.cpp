#include "operators.h"

double operators::C::x = 10; 
