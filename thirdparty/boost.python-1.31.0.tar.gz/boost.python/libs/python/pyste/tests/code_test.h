
struct A {
    int x;
};
