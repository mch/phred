namespace templates {
    
template <class T>
struct Point
{
    T x;
    T y;
};
  
}
