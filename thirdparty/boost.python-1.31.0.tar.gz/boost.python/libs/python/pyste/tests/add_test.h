namespace add_test {

struct C
{
    int x;
};

const int get_x(C& c)
{
    return c.x;
}

}
