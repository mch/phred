namespace inherit4 {
    
struct A
{
    int x;
};  

struct B: A
{
    int y;
};

struct C: B
{
    int z;
};   

}
