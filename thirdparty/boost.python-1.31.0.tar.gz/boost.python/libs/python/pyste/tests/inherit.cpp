#include "inherit.h"

int inherit::C::s = 1;
