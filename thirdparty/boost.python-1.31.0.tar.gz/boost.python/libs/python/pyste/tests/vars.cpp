#include "vars.h"

const Color black = Color(0, 0, 0);
const Color red = Color(255, 0, 0);
const Color green = Color(0, 255, 0);
const Color blue = Color(0, 0, 255);
Color in_use = black; 
