#include "basic.h"

namespace  basic {
    
    int C::static_value = 3;
    const int C::const_static_value = 100;   

}
